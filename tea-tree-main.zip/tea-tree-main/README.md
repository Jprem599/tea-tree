hello world this is new day and make a tea brew and freshen up
go sleep
just have a cup of tea
